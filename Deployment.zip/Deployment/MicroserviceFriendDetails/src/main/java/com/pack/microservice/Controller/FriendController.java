package com.pack.microservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.microservice.dto.FriendDto;
import com.pack.microservice.service.IFriendService;

@RestController
public class FriendController {

	@Autowired
	IFriendService service;
	
	@GetMapping("/getFriendsList/{phoneNumber}")
	public List<Long> getSpecificFried(@PathVariable Long phoneNumber)
	{
		return service.getSpecificFried(phoneNumber);
	}
	
	
	@PostMapping("/createFriend")
	public String createFriends(@RequestBody FriendDto dto)
	{
		return service.createFriend(dto);
		
	  /*List<Long> friendNumList = service.getSpecificFried(dto.getPhoneNumber());
		
	  if(!friendNumList.isEmpty())
	  {
		  for(Long number:friendNumList)
		  {
			  if(number==dto.getFriendNumber())
			  {
				  return "Friend number already exist";
			  }
			  else
			  {
				  boolean flag=service.createFriend(dto);
				  
				  if(flag==true)
				  {
					  return "Friend Details saved successfully";
					  
				  }else
					  return "Friend Details not saved";			 
			  }
		  }
	  }	
	  else
	  {
		  boolean flag=service.createFriend(dto);
		  
		  if(flag==true)
		  {
			  return "Friend Details saved successfully";
			  
		  }else
			  return "Friend Details not saved";	
	  }*/
		  
	}
	
	 
	@GetMapping("/getAllFriends")
	public List<FriendDto> getFriendsList()
	{
		return service.getFriendsList();
		
	}
	
	
	
	
	
}

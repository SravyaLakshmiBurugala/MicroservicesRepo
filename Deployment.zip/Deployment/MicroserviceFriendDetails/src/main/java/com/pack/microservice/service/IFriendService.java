package com.pack.microservice.service;

import java.util.List;

import com.pack.microservice.dto.FriendDto;

public interface IFriendService {
	
	List<FriendDto> getFriendsList();
	
	List<Long> getSpecificFried(Long phoneNumber);
	
	String createFriend(FriendDto dto);
	
	
}

package com.pack.microservice.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.text.html.Option;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.microservice.Entity.Friend;
import com.pack.microservice.dto.FriendDto;
import com.pack.microservice.repository.FriendRepository;
import com.pack.microservice.service.IFriendService;

import ch.qos.logback.core.net.SyslogOutputStream;

@Service
public class FriendServiceImpl implements IFriendService
{
	
	@Autowired
	FriendRepository friendRepository;
	
	@Override
	public String createFriend(FriendDto dto) 
	{
		/*boolean flag=friendRepository.existsById(dto.getId());
		
		if(flag==false)
		{*/
		String message = null;
		
		System.out.println("dto.getFriendNumber() "+dto.getPhoneNumber());
		
		List<Long> freindNumbesList=getSpecificFried(dto.getPhoneNumber());
		
		for(Long friend:freindNumbesList)
		{
			System.out.println("freindNumbesList1::::createFriend::::number"+friend);
		}
		
		System.out.println("freindNumbesList.isEmpty() "+freindNumbesList.isEmpty());
		
		System.out.println("dto.getFriendNumber() "+dto.getFriendNumber());
		
		 if(freindNumbesList.equals(false))
		  {
			System.out.println("Entered into if loop"); 
			 
			  for(Long number:freindNumbesList)
			  {
				  System.out.println("Entered into for loop");
				  
				  if(number==dto.getFriendNumber())
				  {
					  System.out.println("Entered into number check loop");
					  
					  message = "Friend number already exist";
				  }			
				  else
				  {
					Friend friend = new Friend();
						
					BeanUtils.copyProperties(dto, friend);	
							
					friendRepository.save(friend);
					
					message = "Friend Details saved successfully";
					
				  }
			  }
		   }else
		   {
			   Friend friend = new Friend();
				
				BeanUtils.copyProperties(dto, friend);	
						
				friendRepository.save(friend);
				
				message = "Friend Details saved successfully";
		   }
		 
		return message;
		
		/*return true;
		
		}
		else
			return false;*/
	}

	@Override
	public List<FriendDto> getFriendsList() {

	List<Friend> friendsList = friendRepository.findAll();
	
	List<FriendDto> friendDtoList = new ArrayList<>();
	
	for(Friend friend:friendsList)
	{
		FriendDto dto = new FriendDto();
		
		BeanUtils.copyProperties(friend, dto);
		
		friendDtoList.add(dto);
		
	}
		
		return friendDtoList;
	}

	@Override
	public List<Long> getSpecificFried(Long phoneNumber) {
		
		
		System.out.println(friendRepository.findByPhoneNumber(phoneNumber));
		
		List<Friend> friendNumList =friendRepository.findByPhoneNumber(phoneNumber);
		
		List<Long> friendsLongList= new ArrayList<>();
		
		for(Friend friend:friendNumList)
		{
			friendsLongList.add(friend.getFriendNumber());
			System.out.println("freindNumbesList1::::::::number"+friend);
		}
		
		return friendsLongList;
	}

	

}

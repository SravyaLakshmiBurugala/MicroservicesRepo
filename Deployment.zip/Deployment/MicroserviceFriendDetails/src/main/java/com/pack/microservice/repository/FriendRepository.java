package com.pack.microservice.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pack.microservice.Entity.Friend;
import com.pack.microservice.dto.FriendDto;
@Repository
public interface FriendRepository extends JpaRepository<Friend,Integer>
{
	List<Friend> findByPhoneNumber(Long phoneNumber);
	
	
	@Query(value="select count(*) from Friend where friendNumber=? and phoneNumber=?", nativeQuery=true)
	Integer verifyFriendNumber(Long friendNumber,Long phoneNumber);
	
}
package com.pack.microservice.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pack.microservice.model.PlanDetailsDto;

//import org.springframework.cloud.openfeign.FeignClient;

//@FeignClient("PlanDetails")
public interface CustomerPlansFeign {
	
	@RequestMapping("/PlanDetailsApp/getPlans/{planId}")
	public PlanDetailsDto getSpecificPlan(@PathVariable("planId") String planId);
	
}

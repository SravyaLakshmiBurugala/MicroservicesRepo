package com.pack.microservice.service;

import java.util.List;

import com.pack.microservice.Entity.Customer;
import com.pack.microservice.model.CustomerDto;
import com.pack.microservice.model.Login;

public interface ICustomerService 
{
	String saveCustomer(Customer customer);
	
	boolean checkLogin(Login login);
	
	CustomerDto getCustomerPhoneNumber(Long phone);
	
	List<CustomerDto> getAllCustomers();
		
}

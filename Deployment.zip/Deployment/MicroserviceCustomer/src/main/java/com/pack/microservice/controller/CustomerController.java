package com.pack.microservice.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.pack.microservice.Entity.Customer;
import com.pack.microservice.model.CustomerDto;
import com.pack.microservice.model.Login;
import com.pack.microservice.model.PlanDetailsDto;
import com.pack.microservice.service.ICustomerService;

@RestController
//@RibbonClient(name="custribbon")
public class CustomerController 
{
	//String PLAN_URL="http://localhost:3002/PlanDetailsApp/getPlans/{planId}";
	String PLAN_URL="http://PlanDetails/PlanDetailsApp/getPlans/{planId}";
	
	//String FRIEND_URL="http://localhost:3003/FriendDetailsApi/getFriendsList/{phoneNumber}";
	//String FRIEND_URL="http://custribbon/FriendDetailsApi/getFriendsList/{phoneNumber}";
	
	//String FRIEND_URL="http://FriendDetails/FriendDetailsApi/getFriendsList/{phoneNumber}";
	
	long x=System.currentTimeMillis();
	
	
	@Autowired
	ICustomerService service;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	CustomerCircuitService curcuit;

	/*@Autowired
	CustomerPlansFeign planFeign;
	
	@Autowired
	CustomerFriendFeign friendFeign;*/
	
	@PostMapping("/register")/*, produces="application/json")*/
	public String getRegisterDetails(@RequestBody Customer customer)
	{
		System.out.println("Entered into Customer controller");
		
	 return	service.saveCustomer(customer);
	}
	
	@PostMapping("/login")
	public boolean checkLogin(@RequestBody Login login)
	{
		System.out.println("Entered into Login Customer Controller");
		
		return service.checkLogin(login);
	}
	
	@GetMapping("/profile/{phoneNumber}")
	public CustomerDto getProfilePhoneNumber(@PathVariable("phoneNumber") Long phone)
	{
		CustomerDto dto=service.getCustomerPhoneNumber(phone);
		
		
		
		String planId=dto.getPlanId();
		
		//PlanDetailsDto planDto=new RestTemplate().getForObject(PLAN_URL, PlanDetailsDto.class, planId);
		PlanDetailsDto planDto=restTemplate.getForObject(PLAN_URL, PlanDetailsDto.class, planId);
		dto.setPlan(planDto);
		/*Future<PlanDetailsDto>	future=curcuit.getPlanData(planId);
		
		
		
		try
		{
			dto.setPlan(future.get());
		}
		catch(Exception e)
		{
			System.out.println("Exception "+e);
		}*/
		

		long y=System.currentTimeMillis();
		
		System.out.println("Time Taken in Milli Seconds "+x);
		System.out.println("Time Taken in Milli Seconds "+y);
		
		System.out.println("Time Taken in Milli Seconds "+(y-x));
		
		//ResponseEntity<List<Long>> friends = restTemplate.exchange(FRIEND_URL, HttpMethod.GET, null, new ParameterizedTypeReference<List<Long>>() {},phone);
		//List<Long> friendsList=friends.getBody();
		
		List<Long> friendsList=curcuit.getFriends(dto.getPhoneNumber());

		long z=System.currentTimeMillis();
		
		System.out.println("Time Taken in Milli Seconds "+x);
		System.out.println("Time Taken in Milli Seconds "+z);
		
		System.out.println("Time Taken in Milli Seconds "+(z-x));
		
		dto.setFriend(friendsList);
		
		return dto;
		
	}
	
	@GetMapping("/getAllCustomers")
	public List<CustomerDto> getAllCustomers()
	{
		return service.getAllCustomers();
	}
	
}
	
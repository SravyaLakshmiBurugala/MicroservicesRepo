package com.pack.microservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pack.microservice.Entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long>
{

	@Query(value="select count(*) from customer_details where PHONE_NUMBER=? and PASSWORD=?", nativeQuery=true)
	int customerCount(Long phoneNumber,String password);
	
}

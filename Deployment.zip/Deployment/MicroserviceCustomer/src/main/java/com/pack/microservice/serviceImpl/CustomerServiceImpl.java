package com.pack.microservice.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.microservice.Entity.Customer;
import com.pack.microservice.model.CustomerDto;
import com.pack.microservice.model.Login;
import com.pack.microservice.repository.CustomerRepository;
import com.pack.microservice.service.ICustomerService;

import ch.qos.logback.core.net.SyslogOutputStream;


@Service
public class CustomerServiceImpl implements ICustomerService
{

	@Autowired
	//(required=true)
	CustomerRepository customerRepository;
	
	@Override
	public String saveCustomer(Customer customer) 
	{
		System.out.println("Entered into Customer Service Impl");
		
		boolean flag=customerRepository.existsById(customer.getPhoneNumber());
		
		if(flag==false)
		{				
			customerRepository.saveAndFlush(customer);
			
			System.out.println("Details saved");
			//Customer cust=
			
			/*CustomerDto dto=new CustomerDto();
			
			BeanUtils.copyProperties(cust, dto);*/
			
			return "Customer Details saved Successfully";
		}
		else		
			return "Customer Details already exists";
	}

	/*@Override
	public boolean checkLogin(Login login) 
	{
		System.out.println("Entered into CustomerService Impl");
		
		if(customerRepository.existsById(login.getPhoneNumber()))
		{
			System.out.println("Enter into Customer If condition");
			
			Optional<Customer> opt=customerRepository.findById(login.getPhoneNumber());
			
			Customer cust=opt.get();
			
			System.out.println("Entered into customer after repository");
			
			if(cust.getPassword().equals(login.getPassword()))
			{
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}*/
	
	@Override
	public boolean checkLogin(Login login) {
		
		 int count=customerRepository.customerCount(login.getPhoneNumber(), login.getPassword());
		
		 if(count==0)
			 return false;
		 else
			 return true;
	}

	
	

	@Override
	public CustomerDto getCustomerPhoneNumber(Long phone) {
		
		Optional<Customer> opt=customerRepository.findById(phone);
		
		Customer cust=opt.get();
		
		CustomerDto dto=new CustomerDto();
		
		BeanUtils.copyProperties(cust, dto);
		
		return dto;
	}

	@Override
	public List<CustomerDto> getAllCustomers() {
		
	    List<Customer> customersList = customerRepository.findAll();
	    
	    List<CustomerDto> customerDtoList =new ArrayList();
	    
	    for(Customer cust:customersList)
	    {
	    	CustomerDto dto=new CustomerDto();
	    	
	    	BeanUtils.copyProperties(cust, dto);	    
	    	
	    	customerDtoList.add(dto);
	    }
	    
		return customerDtoList;
	}

}

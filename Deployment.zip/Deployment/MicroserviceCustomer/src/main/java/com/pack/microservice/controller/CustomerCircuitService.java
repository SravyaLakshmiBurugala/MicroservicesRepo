package com.pack.microservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.command.AsyncResult;
import com.pack.microservice.model.PlanDetailsDto;


@Service
public class CustomerCircuitService {
	
	private static String FRIEND_URL="http://FriendDetails/FriendDetailsApi/getFriendsList/{phoneNumber}";
	private static String PLAN_URL="http://PlanDetails/PlanDetailsApp/getPlans/{planId}";
	
	@Autowired
	RestTemplate restTemplate;
	
	
	@HystrixCommand(fallbackMethod="getFriendsFallback")
	public List<Long> getFriends(Long phoeNo)
	{
		List<Long> friends=restTemplate.getForObject(FRIEND_URL, List.class , phoeNo);
		
		return friends;
	}
	
	public List<Long> getFriendsFallback(Long phoneNo)
	{
		return new ArrayList<Long>();
	}
	
	
	public Future<PlanDetailsDto> getPlanData(String planId)
	{
		return new AsyncResult<PlanDetailsDto>()
		{
			@Override
			public PlanDetailsDto invoke()
			{
			return new RestTemplate().getForObject(PLAN_URL, PlanDetailsDto.class, planId);
			}	
		};	
	}

}

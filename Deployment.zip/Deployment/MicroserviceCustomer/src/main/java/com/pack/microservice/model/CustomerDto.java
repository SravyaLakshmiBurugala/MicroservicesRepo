package com.pack.microservice.model;

import java.util.List;

public class CustomerDto {
	
	public Long phoneNumber;
	public String name;
	public String password;
	public String planId;
	
	private PlanDetailsDto plan;
	private List<Long> friend;
	
	public PlanDetailsDto getPlan() {
		return plan;
	}
	public void setPlan(PlanDetailsDto plan) {
		this.plan = plan;
	}
	public List<Long> getFriend() {
		return friend;
	}
	public void setFriend(List<Long> friend) {
		this.friend = friend;
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	
	
}

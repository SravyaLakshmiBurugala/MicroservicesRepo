package com.pack.microservice.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

//@FeignClient("FriendDetails")
public interface CustomerFriendFeign {
	
	@RequestMapping("/FriendDetailsApi/getFriendsList/{phoneNumber}")
	public List<Long> getFriendNumber(@PathVariable("phoneNumber") Long phoneNumber);

}

package com.pack.microservice.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.microservice.dto.PlanDetailsDto;
import com.pack.microservice.entity.PlanDetails;
import com.pack.microservice.repository.PlanRepository;
import com.pack.microservice.service.IPlanService;

@Service
public class PlanServiceImpl implements IPlanService
{
	
	@Autowired
	PlanRepository planRepository;
	
	@Override
	public List<PlanDetailsDto> getAllPlans() 
	{
		List<PlanDetails> planList= planRepository.findAll();
		
		List<PlanDetailsDto> planDto=new ArrayList();
		
		for(PlanDetails plan:planList)
		{
			PlanDetailsDto dto=new PlanDetailsDto();
			
			BeanUtils.copyProperties(plan,dto);
			
			planDto.add(dto);
		}
		
		return planDto;
		
	}

	@Override
	public PlanDetailsDto getSpecificPlan(String planId) 
	{	
		Optional<PlanDetails> opt=planRepository.findById(planId);

		PlanDetails plan=opt.get();
		
		PlanDetailsDto dto=new PlanDetailsDto();
		
		BeanUtils.copyProperties(plan, dto);	
		
		return dto;
	}

	@Override
	public boolean createPlans(PlanDetailsDto dto) 
	{
		 boolean flag=planRepository.existsById(dto.getPlanId());
				 
		 if(flag==false)
		 {
			 PlanDetails plan=new PlanDetails();
			 			 
			 BeanUtils.copyProperties(dto, plan);
			 
			 planRepository.save(plan);
			 
			 return true;
			 
		 }
		 else
		 {
			return false; 
		 }
		 
	}

	@Override
	public boolean updatePlanDetails(PlanDetailsDto dto) 
	{
		boolean flag=planRepository.existsById(dto.getPlanId());
		
		if(flag==true)
		{
			PlanDetails plan=new PlanDetails();
			
			BeanUtils.copyProperties(dto, plan);
			
			planRepository.saveAndFlush(plan);
			
			return true;			
		}
		else
			return false;
			
	}

	@Override
	public boolean deletePlan(String planId) 
	{
		boolean flag=planRepository.existsById(planId);
		
		if(flag==true)
		{
			planRepository.deleteById(planId);
			
			return true;
			
		}
		else
		return false;
	}

}

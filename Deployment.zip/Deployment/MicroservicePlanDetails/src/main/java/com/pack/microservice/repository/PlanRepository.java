package com.pack.microservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pack.microservice.entity.PlanDetails;

@Repository
public interface PlanRepository extends JpaRepository<PlanDetails, String> {

}

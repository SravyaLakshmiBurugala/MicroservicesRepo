package com.pack.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.microservice.dto.PlanDetailsDto;
import com.pack.microservice.service.IPlanService;

@RestController
public class PlanDetailsController {

	@Autowired
	IPlanService planService;
	
	@GetMapping(value="/getAllPlans", produces="application/json")
	public List<PlanDetailsDto> getAllPlans()
	{
		return planService.getAllPlans();		
	}
	
	@GetMapping("/getPlans/{planId}")
	public PlanDetailsDto getSpecificPlan(@PathVariable String planId)
	{
		return planService.getSpecificPlan(planId); 
	}
	
	@PostMapping("/createPlan")
	public String createNewPlan(@RequestBody PlanDetailsDto dto)
	{
		boolean flag=planService.createPlans(dto);
		
		if(flag==true)
		{
			return "Plan Details Created Successfully";
		}
		else			
			return "Plan already exist";		
	}
	
	@PutMapping("/updatePlan")
	public String updatePlan(@RequestBody PlanDetailsDto dto)
	{
		
		boolean flag=planService.updatePlanDetails(dto);
		
		if(flag==true)
		
			return "Plan Details Updated successfully";
		
		else
			
			return "Plan does not exist in system";
	}
	
	@DeleteMapping("/plans/{delete}")
	public String deletePlan(@RequestParam String planId)
	{
		boolean flag=planService.deletePlan(planId);
		
		if(flag==true)
		{
			return "Plan deleted Successfully";
		}
		else
		{
			return "Plan does not exist in system";
		}
		
	}
	
	
}

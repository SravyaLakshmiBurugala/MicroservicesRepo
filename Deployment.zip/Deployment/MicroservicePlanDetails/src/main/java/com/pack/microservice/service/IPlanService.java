package com.pack.microservice.service;

import java.util.List;

import com.pack.microservice.dto.PlanDetailsDto;

public interface IPlanService {
	
	 List<PlanDetailsDto> getAllPlans();
	
	 PlanDetailsDto getSpecificPlan(String plandId);
	
	 boolean createPlans(PlanDetailsDto dto);
	
	 boolean updatePlanDetails(PlanDetailsDto dto);
	
	 boolean deletePlan(String planId); 

}

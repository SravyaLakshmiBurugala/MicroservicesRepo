package com.pack.microservice.Dto;

import java.util.Date;

public class CallDetailsDto {
	
	private Long callId;
	private Long calledBy;
	private Long calledTo;
	private Date calledOn;
	private Long duaration;
	
	
	public Long getCallId() {
		return callId;
	}
	public void setCallId(Long callId) {
		this.callId = callId;
	}
	public Long getCalledBy() {
		return calledBy;
	}
	public void setCalledBy(Long calledBy) {
		this.calledBy = calledBy;
	}
	public Long getCalledTo() {
		return calledTo;
	}
	public void setCalledTo(Long calledTo) {
		this.calledTo = calledTo;
	}
	public Date getCalledOn() {
		return calledOn;
	}
	public void setCalledOn(Date calledOn) {
		this.calledOn = calledOn;
	}
	public Long getDuaration() {
		return duaration;
	}
	public void setDuaration(Long duaration) {
		this.duaration = duaration;
	}
		
			
}

package com.pack.microservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.microservice.Dto.CallDetailsDto;
import com.pack.microservice.Entity.CallDetails;
import com.pack.microservice.service.ICallDetailsService;

@RestController
public class CallDetailsController 
{
	@Autowired
	ICallDetailsService service;
	
	@GetMapping("/getAllCallDetails")
	public List<CallDetailsDto> getAllCallDetails()
	{
		return service.getAllCallDetails();		
	}
	
	@GetMapping("/getCallDetails/{callId}")
	public CallDetailsDto getSpeicificCall(@PathVariable Long callId)
	{
		return service.getSpecificCalls(callId);
		 
	}
	
	@GetMapping("/getCallDetails/PhoneNumber")
	public List<CallDetailsDto> getSpecificCalledBy(@RequestParam Long calledBy)
	{
		return service.getSpecificCalledBy(calledBy);
				
	}
	
	
}

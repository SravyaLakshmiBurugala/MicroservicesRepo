package com.pack.microservice.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.microservice.Dto.CallDetailsDto;
import com.pack.microservice.Entity.CallDetails;
import com.pack.microservice.repository.callDetailsRepository;
import com.pack.microservice.service.ICallDetailsService;

@Service
public class CallDetailsServiceImpl implements ICallDetailsService
{

	@Autowired
	callDetailsRepository repository;
	
	@Override
	public List<CallDetailsDto> getAllCallDetails() {
		
	  List<CallDetails> callDetailsList = repository.findAll();
		
	  List<CallDetailsDto> callDetailsDtoList =new ArrayList<>();
	  
	  for(CallDetails  call: callDetailsList)
	  {
		  CallDetailsDto dto=new CallDetailsDto();
		  
		  BeanUtils.copyProperties(call, dto);
		  
		  callDetailsDtoList.add(dto);
		  
	  }
		return callDetailsDtoList;
		
	}

	@Override
	public CallDetailsDto getSpecificCalls(Long callId) {
		
		Optional<CallDetails> opt = repository.findById(callId);
		
		CallDetails callDetails=opt.get();
		
		CallDetailsDto callDetailsdto=new CallDetailsDto();
		
		BeanUtils.copyProperties(callDetails, callDetailsdto);
		
		return callDetailsdto;
	}

	@Override
	public List<CallDetailsDto> getSpecificCalledBy(Long calledBy) {
		
		List<CallDetails> callDetailsList = repository.findByCalledBy(calledBy);
		
		List<CallDetailsDto> callDetailsListDto = new ArrayList<>();
		
		for(CallDetails call:callDetailsList)
		{
			CallDetailsDto dto=new CallDetailsDto();
			
			BeanUtils.copyProperties(call, dto);
			
			callDetailsListDto.add(dto);
		}
		
		return callDetailsListDto;
	}

}

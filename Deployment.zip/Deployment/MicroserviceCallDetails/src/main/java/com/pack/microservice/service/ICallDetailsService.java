package com.pack.microservice.service;

import java.util.List;

import com.pack.microservice.Dto.CallDetailsDto;
import com.pack.microservice.Entity.CallDetails;

public interface ICallDetailsService {
	
	 List<CallDetailsDto> getAllCallDetails();
	 
	 CallDetailsDto getSpecificCalls(Long callId);
	 
	 List<CallDetailsDto> getSpecificCalledBy(Long calledBy);
	 
}
